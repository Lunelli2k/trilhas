<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;

Route::get('/api', function () {
    return view('welcome');
});

Route::get('/teste', function () {
    return 'Hello world';
});

// Rota API - IMPORTANTE: sem middleware de web
Route::any('/api/handle', [ApiController::class, 'handleRequest']);