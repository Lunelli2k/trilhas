<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApiController extends Controller
{
    public function handleRequest(Request $request)
    {
        // Desative completamente qualquer uso de sessão
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_abort();
        }
        
        config([
            'session.driver' => 'array',
            'session.cookie' => 'no-cookie'
        ]);

        return response()->json([
            'status' => 'success',
            'data' => $request->all()
        ]);
    }
}